const Header = () => {
    return (
        <h1> This is the APP HEADER</h1>
    )
}

export default Header