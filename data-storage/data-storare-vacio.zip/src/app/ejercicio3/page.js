'use client';

const Ejercicio5 = () => {

    return (
        <div>
            <h2>
                Ejercicio 4
            </h2>
            <p>
                Uso de cookies
            </p>
        </div>
    )
} 

export default Ejercicio5