'use client';

const Ejercicio5 = () => {

    return (
        <div>
            <h2>
                Ejercicio 5
            </h2>
            <p>
                USo de geolocalización
            </p>
        </div>
    )
} 

export default Ejercicio5