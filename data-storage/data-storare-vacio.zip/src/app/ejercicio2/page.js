'use client';

const Ejercicio5 = () => {

    return (
        <div>
            <h2>
                Ejercicio 2
            </h2>
            <p>
                Uso de fetch / axios
            </p>
        </div>
    )
} 

export default Ejercicio5